// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const DB_CONFIG = {
  apiKey: "AIzaSyBiUA47QfbtCPo06VB2JznmFftjKEn3PDU",
  authDomain: "trelloclone2.firebaseapp.com",
  projectId: "trelloclone2",
  storageBucket: "trelloclone2.appspot.com",
  messagingSenderId: "799178052816",
  appId: "1:799178052816:web:870a87c398b60ff0c2fad5",
  measurementId: "G-FS2QCPCVLM"
};

  